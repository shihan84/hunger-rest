#!/bin/bash
cd "$(dirname "$0")/mobile_backend"
../venv/bin/python main.py
