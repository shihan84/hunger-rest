from restaurant_billing.app import bootstrap

if __name__ == "__main__":
	bootstrap()
