# HUNGER Restaurant Billing System - Pillow-Fixed Installer

## Professional Desktop Billing System

This installer handles Pillow dependency issues that commonly occur on Windows.

### Features
- 🧾 **Complete Billing System**: Full restaurant billing with GST compliance
- 💰 **GST Calculation**: Automatic GST calculation and reporting
- 💳 **UPI Integration**: QR code generation for payments
- 👥 **User Management**: Role-based access control
- 📊 **Reports**: Sales reports and analytics
- 🔄 **Auto Updates**: Automatic update notifications
- 🗄️ **SQLite Database**: Built-in database, no separate installation needed

### Installation

#### Quick Start
1. **Right-click** `install.bat` and select "Run as Administrator"
2. **Follow** the installation prompts
3. **Launch** from desktop shortcut

### Pillow Dependency Fixes

This installer includes several fixes for Pillow installation issues:

1. **Pre-compiled Wheels**: Uses binary wheels to avoid compilation
2. **Version Fallback**: Tries multiple Pillow versions if one fails
3. **Alternative Installation**: Provides fallback methods
4. **Error Handling**: Continues installation even if Pillow fails

### System Requirements
- Windows 7 or later
- Python 3.11+ (installer will check and guide you)
- 4GB RAM minimum
- 500MB free disk space
- Internet connection (for dependency installation)

### Troubleshooting Pillow Issues

#### If Pillow installation fails:
1. **Try Manual Installation**:
   ```bash
   pip install Pillow==9.5.0
   ```

2. **Use Alternative Version**:
   ```bash
   pip install Pillow==10.0.1 --only-binary=all
   ```

3. **Install Visual C++ Build Tools**:
   - Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
   - Install "C++ build tools" workload
   - Restart and try again

4. **Use Conda Instead**:
   ```bash
   conda install pillow
   ```

### What Gets Installed
- Desktop billing application
- Python dependencies (with Pillow fixes)
- SQLite Database (built-in)
- Desktop shortcuts
- Start menu entries

### Default Login
- Username: `owner`
- Password: `1234`

### Support
- GitHub: https://github.com/shihan84/hunger-rest
- Issues: https://github.com/shihan84/hunger-rest/issues

### Version
1.0.0
