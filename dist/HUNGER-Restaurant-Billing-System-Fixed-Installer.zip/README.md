# HUNGER Restaurant Billing System - Fixed Installer Package

## Professional Desktop Billing System

This package provides a complete desktop billing system with multiple installation options and robust error handling.

### Features
- 🧾 **Complete Billing System**: Full restaurant billing with GST compliance
- 💰 **GST Calculation**: Automatic GST calculation and reporting
- 💳 **UPI Integration**: QR code generation for payments
- 👥 **User Management**: Role-based access control
- 📊 **Reports**: Sales reports and analytics
- 🔄 **Auto Updates**: Automatic update notifications
- 🗄️ **SQLite Database**: Built-in database, no separate installation needed

### Installation Options

#### Option 1: Robust Installer (Recommended)
- **File**: `install.bat`
- **Usage**: Right-click → "Run as Administrator"
- **Features**: 
  - Full error handling and validation
  - Automatic Python 3.11.7 installation
  - Automatic Git for Windows installation
  - Complete application setup
  - Desktop shortcuts and start menu integration

#### Option 2: Simple Installer
- **File**: `install_simple.bat`
- **Usage**: Right-click → "Run as Administrator"
- **Features**: 
  - Basic installation without complex error handling
  - Assumes Python is already installed
  - Quick setup for experienced users

### System Requirements
- Windows 7 or later
- Python 3.11+ (robust installer will install automatically)
- 4GB RAM minimum
- 500MB free disk space
- Internet connection (for dependency installation)

### Troubleshooting

#### If you get "return non-zero status 1" error:
1. **Check Administrator Privileges**: Make sure you're running as Administrator
2. **Check Python Installation**: Ensure Python 3.11+ is installed
3. **Check Internet Connection**: Required for downloading dependencies
4. **Try Simple Installer**: Use `install_simple.bat` if the robust installer fails
5. **Manual Installation**: 
   - Install Python 3.11+ from https://python.org
   - Run: `pip install -r requirements.txt`
   - Run: `python main.py`

#### Common Issues:
- **Python not found**: Install Python 3.11+ from https://python.org
- **Permission denied**: Run as Administrator
- **Network error**: Check internet connection
- **File not found**: Ensure all files are in the same directory

### Default Login
- Username: `owner`
- Password: `1234`

### Support
- GitHub: https://github.com/shihan84/hunger-rest
- Issues: https://github.com/shihan84/hunger-rest/issues

### Version
1.0.0
