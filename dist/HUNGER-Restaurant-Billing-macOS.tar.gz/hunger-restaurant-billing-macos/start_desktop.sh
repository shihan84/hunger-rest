#!/bin/bash
cd "$(dirname "$0")"
./venv/bin/python main.py
